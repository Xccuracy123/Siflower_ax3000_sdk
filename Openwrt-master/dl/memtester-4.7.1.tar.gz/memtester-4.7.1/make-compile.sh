echo exec "$CC" -c '${1+"$@"}'
