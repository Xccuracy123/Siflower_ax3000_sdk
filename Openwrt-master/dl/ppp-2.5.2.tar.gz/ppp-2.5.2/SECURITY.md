Security issues are handled by the maintainer, Paul Mackerras <paulus@ozlabs.org>.

If you wish to encrypt an email to the maintainer, use GPG with the
key 040F1D49EC9DBB8C, obtainable from the usual keyservers.
