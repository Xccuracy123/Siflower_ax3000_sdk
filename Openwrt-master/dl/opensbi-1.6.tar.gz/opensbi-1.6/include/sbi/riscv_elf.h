#ifndef __RISCV_ELF_H__
#define __RISCV_ELF_H__

#define R_RISCV_RELATIVE	3

#endif
