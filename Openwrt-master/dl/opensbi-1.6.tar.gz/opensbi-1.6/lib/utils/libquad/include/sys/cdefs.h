/*
 * SPDX-License-Identifier: BSD-2-Clause
 *
 * Copyright (c) 2021 Jessica Clarke <jrtc27@jrtc27.com>
 */

#ifndef __SYS_CDEFS_H__
#define __SYS_CDEFS_H__

#define __FBSDID(s) struct __hack

#endif
