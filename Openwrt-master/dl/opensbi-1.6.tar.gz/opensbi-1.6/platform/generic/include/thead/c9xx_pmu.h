
#ifndef __RISCV_THEAD_C9XX_PMU_H____
#define __RISCV_THEAD_C9XX_PMU_H____

void thead_c9xx_register_pmu_device(void);

#endif // __RISCV_THEAD_C9XX_PMU_H____
